
from flask import Flask ,request,render_template,redirect,url_for
from sympy import im
from werkzeug.utils import secure_filename
import glob,os,json
import numpy as np, json, os.path, glob, os, cv2
import pandas as pd
from info import *;

app = Flask(__name__)
app.config['IMG_FOLDER'] = os.path.join('static', 'images') #이미지 파일의 경로 지정

imgpaths = glob.glob('/Users/kangwook/Desktop/Captone/댕댕/save_img/*.jpg')
model, names, device = v5_load('/Users/kangwook/Desktop/Captone/댕댕/exp3/weights/best.pt', mode='cpu')
colors = setcolor(mode='random')
savepath2 = '/Users/kangwook/Desktop/Captone/댕댕/result/det/'
savepath1 = '/Users/kangwook/Desktop/Captone/yolov5/static/'

@app.route('/fileupload', methods=['POST'])


def fileupload():
    if request.method == 'POST':
        f = request.files['file']
        f.save('/Users/kangwook/Desktop/Captone/댕댕/save_img/' + secure_filename(f.filename))
        return 'upload Success'




@app.route('/result',methods = ['GET'])
def result():
    for imgpath in imgpaths:
        img = imgload(imgpath)

        _img = preprocessing(img,model,device)
        txt =v5_det(_img,img,model)
        d_img =yolodraw(img,txt,colors,(0,1,2,3,4,5), mode='det')

        if len(txt) == 0:
            continue
        if len(txt)>0:
            imgname = savepath1 + imgpath.split('/')[7]
            print(imgpath)
            cv2.imwrite(imgname,d_img)

            txtname1 = savepath2 + imgpath.split('/')[7]
            print(txtname1)
            txtname = txtname1.replace('jpg', 'txt')
            txtname = txtname.replace('d_img', 'det')
            print(txtname)

            df_txt = pd.DataFrame(txt)
            print(df_txt)
            df_txt = df_txt.astype({0: int})
            df_txt.to_csv(txtname, sep = ' ', index = False, header = False)
            return redirect('/showimg')
    


@app.route('/showimg',methods=['GET'])
def showimg():
    list_of_files = glob.glob('/Users/kangwook/Desktop/Captone/댕댕/result/det/*')
    latest_file = max(list_of_files, key=os.path.getctime)
    with open(latest_file) as f:
        lines = f.readline()
        result = lines.split(' ')
        col = ['class', 'x', 'y', 'w', 'h']
        result = dict(zip(col,result))
        info = json.dumps(result)
    # list_of_files2 = glob.glob('/Users/kangwook/Desktop/Captone/static/*.jpg')
    list_of_files2 = glob.glob('/Users/kangwook/Desktop/Captone/yolov5/static/*.jpg')
    latest_file2 = max(list_of_files2, key=os.path.getctime)
    result = latest_file2.split('/')[6]
    print(result)
    return render_template("index.html",img_file=result,info=info)



    






    
        
            
if __name__ == "__main__": 
     app.run(host='localhost', port='5001', debug=True)
